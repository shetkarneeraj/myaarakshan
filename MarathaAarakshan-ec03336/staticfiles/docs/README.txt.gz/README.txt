मराठा आरक्षण मंच - डॉक्युमेंट्स फोल्डर

हा फोल्डर सरकारी कागदपत्रे आणि फॉर्म्ससाठी आहे:

1. maratha_reservation_gr.pdf - मुख्य शासन निर्णय
2. application_form.pdf - अर्ज फॉर्म  
3. eligibility_gr.pdf - पात्रता निकष GR
4. committee_order.pdf - समिती गठन आदेश
5. amendment_2024.pdf - 2024 सुधारणा
6. affidavit_form.pdf - हलफनामा फॉर्म
7. family_consent.pdf - कुटुंब सहमती फॉर्म
8. complete_guide.pdf - संपूर्ण मार्गदर्शक
9. faq_booklet.pdf - FAQ पुस्तिका

सध्या हे सर्व डेमो files आहेत. वास्तविक implementation मध्ये येथे अस्सल PDF files असतील.
